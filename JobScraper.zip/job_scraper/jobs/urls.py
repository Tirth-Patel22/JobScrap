from django.urls import path
from . import views

urlpatterns = [
    path('', views.job_search, name='job_search'),
    path('export_excel/', views.export_excel, name='export_excel'),
]
