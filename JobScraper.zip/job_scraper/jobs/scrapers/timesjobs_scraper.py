from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def scrape_timesjobs(keyword, location, pages=2):
    options = Options()
    options.add_argument("--headless")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")

    service = Service(executable_path="chromedriver-win64\chromedriver.exe")
    driver = webdriver.Chrome(service=service, options=options)

    all_jobs = []

    for page in range(1, pages + 1):
        url = f"https://www.timesjobs.com/candidate/job-search.html?searchType=personalizedSearch&from=submit&txtKeywords={keyword}&txtLocation={location}&sequence={page}&startPage={page}"
        driver.get(url)
        wait = WebDriverWait(driver, 10)

        try:
            job_cards = wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div.srp-card")))
        except:
            print(f"No jobs found on page {page}")
            continue

        print(f"Found {len(job_cards)} jobs on page {page}")

        for job in job_cards:
            try:
                title = job.find_element(By.CSS_SELECTOR, "h2.mb-1").text
            except:
                title = ""

                # Company
            try:
                company = job.find_element(By.CSS_SELECTOR, "div.text-xs span").text
            except:
                company = ""

            # Posted date
            try:
                posted_date = job.find_element(By.CSS_SELECTOR, "div.text-xs").text.split("Posted on:")[-1].strip()
            except:
                posted_date = ""

            # Location
            try:
                location_element = job.find_element(By.XPATH, ".//span[i[contains(@class,'locations-icon')]]")
                location_text = location_element.text.strip()
            except:
                location_text = ""

            # Experience
            try:
                experience = job.find_element(By.XPATH, ".//span[contains(text(),'Yrs')]").text
            except:
                experience = ""

            # Salary
            try:
                salary = job.find_element(By.XPATH, ".//span[contains(text(),'Not disclosed') or contains(text(),'₹')]").text
            except:
                salary = ""

            # Skills
            try:
                skills_elements = job.find_elements(By.CSS_SELECTOR, "div.mt-4 span.skill-tag")
                skills = ", ".join([s.text for s in skills_elements])
            except:
                skills = ""

            # Job URL
            try:
                job_url = job.find_element(By.CSS_SELECTOR, "a").get_attribute("href")
            except:
                job_url = ""

            all_jobs.append({
                "title": title,
                "company": company,
                "location": location_text,
                "experience": experience,
                "salary": salary,
                "skills": skills,
                "posted_date": posted_date,
                "job_url": job_url
            })

        time.sleep(2)

    driver.quit()
    return all_jobs
