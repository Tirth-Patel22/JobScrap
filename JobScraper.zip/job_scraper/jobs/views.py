from django.shortcuts import render
from .models import Job
from .scrapers.timesjobs_scraper import scrape_timesjobs
from django.core.paginator import Paginator
from django.http import HttpResponse
import pandas as pd

def job_search(request):
    if request.method == "POST":
        keyword = request.POST.get("keyword")
        location = request.POST.get("location")

        # Fetch jobs from TimesJobs
        jobs_list = scrape_timesjobs(keyword, location, pages=2)

        saved_count = 0
        for job in jobs_list:
            obj, created = Job.objects.get_or_create(
                title=job["title"],
                company=job["company"],
                location=job["location"],
                defaults={
                    "skills": job["skills"],
                    "posted_date": job["posted_date"],
                    "job_url": job["job_url"]
                }
            )
            if created:
                saved_count += 1

        all_jobs = Job.objects.all().order_by("-id")
        paginator = Paginator(all_jobs, 10)
        page_number = request.GET.get("page")
        page_obj = paginator.get_page(page_number)

        message = f"{saved_count} jobs fetched & saved successfully."

        return render(request, "jobs/index.html", {"page_obj": page_obj, "message": message})

    else:
        all_jobs = Job.objects.all().order_by("-id")
        paginator = Paginator(all_jobs, 10)
        page_number = request.GET.get("page")
        page_obj = paginator.get_page(page_number)
        return render(request, "jobs/index.html", {"page_obj": page_obj})

def export_excel(request):
    jobs = Job.objects.all().values()
    df = pd.DataFrame(jobs)
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=jobs.xlsx'
    df.to_excel(response, index=False)
    return response
