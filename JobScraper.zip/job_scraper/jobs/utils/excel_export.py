import pandas as pd
from django.http import HttpResponse

def export_jobs_to_excel(jobs):
    df = pd.DataFrame(jobs)
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=jobs.xlsx'
    df.to_excel(response, index=False)
    return response
