# Django Job Aggregation Tool

## Features
- JobsLoker Scraping
- Pagination Support
- Save Jobs to Database
- Excel Export
- Django Web Interface

## Tech Stack
- Python
- Django
- BeautifulSoup
- Requests
- openpyxl

## How to Run
pip install django requests beautifulsoup4 openpyxl
python manage.py migrate
python manage.py runserver

## Output
- Jobs saved in database
- Excel download
